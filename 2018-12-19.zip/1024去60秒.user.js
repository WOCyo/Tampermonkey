// ==UserScript==
// @name         1024去60秒
// @namespace    http://tampermonkey.net/
// @version      1.1.3
// @description  去除1024的60秒屏蔽
// @author       明月天QQ791290123
// @match        http://*/*
// @include      *.t66y.*
// @include      */*.t66y.com/*
// @grant        none
// ==/UserScript==

(function() {
readS= null;
r1eadS= null;
re1adS= null;
rea1dS= null;
read1S= null;
readS1= null;
r2eadS= null;
re2adS= null;
rea2dS= null;
read2S= null;
readS2= null;
r3eadS= null;
re3adS= null;
rea3dS= null;
read3S= null;
readS3= null;
r4eadS= null;
re4adS= null;
rea4dS= null;
read4S= null;
readS4= null;
})();
